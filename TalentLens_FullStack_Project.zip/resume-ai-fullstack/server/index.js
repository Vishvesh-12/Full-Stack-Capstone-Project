const express = require('express');
const cors = require('cors');
const multer = require('multer');
const pdfParse = require('pdf-parse');
const { screenResumes } = require('./screening');
const app = express();
app.use(cors());
app.use(express.json({limit:'2mb'}));
const upload = multer({storage:multer.memoryStorage(),limits:{fileSize:10*1024*1024,files:30},fileFilter:(req,file,cb)=>cb(null,file.mimetype==='application/pdf' || file.originalname.toLowerCase().endsWith('.pdf'))});

app.get('/api/health',(req,res)=>res.json({ok:true,service:'TalentLens screening API'}));
app.post('/api/screen',upload.array('resumes',30),async(req,res)=>{
  try {
    const jd=(req.body.jobDescription||'').trim();
    if(!jd) return res.status(400).json({error:'Add a job description before screening.'});
    if(!req.files?.length) return res.status(400).json({error:'Upload at least one PDF resume.'});
    const candidates=[];
    for(const file of req.files){
      try{
        const parsed=await pdfParse(file.buffer);
        const text=(parsed.text||'').trim();
        if(text.length<20){candidates.push({filename:file.originalname,error:'No readable text found. This may be a scanned PDF.'});continue;}
        candidates.push({filename:file.originalname,text});
      }catch(e){candidates.push({filename:file.originalname,error:'Could not parse this PDF.'});}
    }
    const valid=candidates.filter(c=>c.text);
    if(!valid.length) return res.status(422).json({error:'No readable resume text was found. Try text-based PDFs.'});
    const results=screenResumes(jd,valid);
    res.json({results, skipped:candidates.filter(c=>c.error).map(c=>({filename:c.filename,reason:c.error}))});
  }catch(e){console.error(e);res.status(500).json({error:'Screening failed. Check the uploaded PDFs and try again.'});}
});
const PORT=process.env.PORT||5000;
app.listen(PORT,()=>console.log(`API running on http://localhost:${PORT}`));
