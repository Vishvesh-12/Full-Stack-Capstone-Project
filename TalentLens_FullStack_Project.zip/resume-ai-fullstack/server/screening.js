// Lightweight NLP scoring aligned with the notebook's skill + TF-IDF + cosine workflow.
const SKILLS=['python','java','c++','sql','machine learning','deep learning','data analysis','data science','pandas','numpy','scikit learn','scikit-learn','tensorflow','keras','power bi','tableau','excel','statistics','nlp','computer vision','aws','azure','javascript','react','node.js','html','css','fastapi','flask','git','docker','communication','problem solving'];
const STOP=new Set(('a an the and or is are was were be been being to of in on for with from by as at this that it its we you your our their they candidate role required preferred experience knowledge skills ability plus using use work working strong good have has had into about across').split(' '));
function clean(text){return String(text||'').toLowerCase().replace(/[^a-z0-9+#.\s]/g,' ').replace(/\s+/g,' ').trim();}
function tokens(text){return clean(text).split(' ').filter(t=>t && !STOP.has(t));}
function extractSkills(text){const normalized=clean(text);return SKILLS.filter(s=>new RegExp(`(^|\\\\s)${s.replace(/[.*+?^${}()|[\\]\\\\]/g,'\\\\$&').replace(/\\s+/g,'\\\\s+')}(?=\\\\s|$)`,'i').test(normalized));}
function tfidf(docs){
 const terms=docs.map(d=>tokens(d)); const df={};
 terms.forEach(ts=>new Set(ts).forEach(t=>df[t]=(df[t]||0)+1));
 return terms.map(ts=>{const counts={};ts.forEach(t=>counts[t]=(counts[t]||0)+1);const v={};Object.entries(counts).forEach(([t,n])=>v[t]=(n/ts.length)* (Math.log((docs.length+1)/((df[t]||0)+1))+1));return v;});
}
function cosine(a,b){let dot=0,na=0,nb=0;for(const [k,v] of Object.entries(a)){na+=v*v;if(b[k])dot+=v*b[k];}for(const v of Object.values(b))nb+=v*v;return na&&nb?dot/(Math.sqrt(na)*Math.sqrt(nb)):0;}
function screenResumes(jd,candidates){
 const jdSkills=extractSkills(jd);
 const vectors=tfidf([jd,...candidates.map(c=>c.text)]);
 return candidates.map((c,i)=>{
   const candidateSkills=extractSkills(c.text);
   const matched=jdSkills.filter(s=>candidateSkills.includes(s));
   const missing=jdSkills.filter(s=>!candidateSkills.includes(s));
   const skillMatch=jdSkills.length?matched.length/jdSkills.length:0;
   const similarity=cosine(vectors[0],vectors[i+1]);
   const finalScore=.6*skillMatch+.4*similarity;
   return {filename:c.filename,rank:0,skillMatch,similarity,finalScore,matchedSkills:matched,missingSkills:missing,resumeSkills:candidateSkills,requiredSkills:jdSkills,wordCount:tokens(c.text).length};
 }).sort((a,b)=>b.finalScore-a.finalScore).map((r,i)=>({...r,rank:i+1}));
}
module.exports={screenResumes};
