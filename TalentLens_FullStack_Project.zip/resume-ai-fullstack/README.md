# TalentLens — AI Resume Screening & Candidate Ranking

Interactive full-stack resume screening prototype using React, CSS, Node.js, Express and PDF parsing. It adapts the uploaded project notebook's flow: PDF text extraction, skill dictionary matching, TF-IDF-like term weighting, cosine similarity, weighted final score, and ranked candidates.

## Run locally

Requirements: Node.js 18+ and npm.

```bash
npm install
npm run dev
```

Open the Vite URL printed in the terminal (normally http://localhost:5173). Express API runs on http://localhost:5000.

## Features
- Paste/edit a job description
- Upload multiple text-based PDF resumes (up to 30, 10MB each)
- Per-resume skill match, text similarity, and overall score
- Ranking table, filtering, expandable skill breakdown, missing/matched skills
- Session-only processing; no database or persistent file storage

## Scoring
`final = 0.60 * skill_match + 0.40 * cosine_similarity`

This is a prototype decision-support tool, not a hiring decision maker. Keyword detection can miss equivalent terms and PDFs containing scanned images may need OCR. Review outputs for fairness and accuracy.
